"""Test-set evaluation: accuracy, per-class precision/recall/F1, confusion matrix."""

from __future__ import annotations

from pathlib import Path

import numpy as np

from config import CLASS_IDS, CLASS_NAMES
from data_preprocessing import load_image, resolve_image_path


def classification_report(y_true: np.ndarray, y_pred: np.ndarray) -> dict:
    """Multiclass precision, recall, F1 and a confusion matrix. No sklearn needed."""
    n_classes = len(CLASS_IDS)
    matrix = np.zeros((n_classes, n_classes), dtype=int)
    for true, pred in zip(y_true, y_pred):
        matrix[int(true), int(pred)] += 1

    per_class = []
    for index, class_id in enumerate(CLASS_IDS):
        tp = int(matrix[index, index])
        support = int(matrix[index].sum())
        predicted = int(matrix[:, index].sum())
        precision = tp / predicted if predicted else 0.0
        recall = tp / support if support else 0.0
        f1 = (2 * precision * recall / (precision + recall)) if (precision + recall) else 0.0
        per_class.append(
            {
                "class_id": class_id,
                "name": CLASS_NAMES[class_id],
                "precision": round(precision, 4),
                "recall": round(recall, 4),
                "f1": round(f1, 4),
                "support": support,
            }
        )
    accuracy = float(np.trace(matrix) / matrix.sum()) if matrix.sum() else 0.0
    macro_f1 = float(np.mean([row["f1"] for row in per_class])) if per_class else 0.0
    return {
        "accuracy": round(accuracy, 4),
        "macro_f1": round(macro_f1, 4),
        "per_class": per_class,
        "confusion_matrix": matrix.tolist(),
    }


def evaluate_split(model, records: list[dict], train_root: Path, batch_size: int) -> dict:
    class_to_index = {class_id: i for i, class_id in enumerate(CLASS_IDS)}
    y_true = []
    y_pred = []
    for start in range(0, len(records), batch_size):
        chunk = records[start : start + batch_size]
        images = np.stack(
            [load_image(resolve_image_path(train_root, record)) for record in chunk]
        )
        probabilities = model.predict(images, verbose=0)
        y_pred.extend(np.argmax(probabilities, axis=1).tolist())
        y_true.extend(class_to_index[record["classname"]] for record in chunk)
    return classification_report(np.asarray(y_true), np.asarray(y_pred))
