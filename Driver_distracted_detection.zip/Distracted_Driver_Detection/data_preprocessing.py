"""Data loading, driver-grouped splitting, resizing, and augmentation.

Expected State Farm layout after unzipping imgs.zip and placing the csv:

    data/
      driver_imgs_list.csv          columns: subject, classname, img
      imgs/train/c0/img_xxxx.jpg
      imgs/train/c1/...
      imgs/test/img_xxxx.jpg        unlabelled competition test set
"""

from __future__ import annotations

import csv
from collections import defaultdict
from pathlib import Path

import numpy as np
from PIL import Image, ImageEnhance

from config import AUGMENTATION, CLASS_IDS, IMAGE_SIZE, RANDOM_SEED


def load_driver_index(csv_path: Path) -> list[dict]:
    """Read driver_imgs_list.csv into records of subject, class, filename."""
    records = []
    with csv_path.open(newline="") as handle:
        reader = csv.DictReader(handle)
        fields = {name.strip().lower(): name for name in (reader.fieldnames or [])}
        subject_key = fields.get("subject")
        class_key = fields.get("classname") or fields.get("class")
        img_key = fields.get("img") or fields.get("filename")
        if not (subject_key and class_key and img_key):
            raise ValueError(
                "driver_imgs_list.csv must have subject, classname, and img columns."
            )
        for row in reader:
            records.append(
                {
                    "subject": row[subject_key].strip(),
                    "classname": row[class_key].strip(),
                    "img": row[img_key].strip(),
                }
            )
    if not records:
        raise ValueError(f"No rows found in {csv_path}")
    return records


def driver_grouped_split(
    records: list[dict],
    val_fraction: float = 0.15,
    test_fraction: float = 0.15,
    seed: int = RANDOM_SEED,
) -> dict[str, list[dict]]:
    """Split by driver id so the same person never appears in two sets.

    A random image split leaks identity: the same driver in the same cabin
    shows up in train and test, and accuracy is then partly face recognition.
    The competition itself holds drivers out of the public test set.
    """
    by_driver: dict[str, list[dict]] = defaultdict(list)
    for record in records:
        by_driver[record["subject"]].append(record)

    drivers = sorted(by_driver)
    rng = np.random.default_rng(seed)
    rng.shuffle(drivers)

    n = len(drivers)
    n_test = max(1, int(round(n * test_fraction)))
    n_val = max(1, int(round(n * val_fraction)))
    if n_test + n_val >= n:
        raise ValueError("Not enough drivers to form train, validation, and test sets.")

    test_drivers = set(drivers[:n_test])
    val_drivers = set(drivers[n_test : n_test + n_val])
    train_drivers = set(drivers[n_test + n_val :])

    splits = {"train": [], "val": [], "test": []}
    for driver, rows in by_driver.items():
        if driver in test_drivers:
            splits["test"].extend(rows)
        elif driver in val_drivers:
            splits["val"].extend(rows)
        else:
            splits["train"].extend(rows)
    splits["train_drivers"] = sorted(train_drivers)
    splits["val_drivers"] = sorted(val_drivers)
    splits["test_drivers"] = sorted(test_drivers)
    return splits


def resolve_image_path(train_root: Path, record: dict) -> Path:
    return train_root / record["classname"] / record["img"]


def load_image(path: Path, size: tuple[int, int] = IMAGE_SIZE) -> np.ndarray:
    """Load a dashboard frame, resize to the network input, scale to [0, 1]."""
    with Image.open(path) as image:
        image = image.convert("RGB").resize(size, Image.BILINEAR)
        array = np.asarray(image, dtype=np.float32) / 255.0
    return array


def augment_image(array: np.ndarray, rng: np.random.Generator | None = None) -> np.ndarray:
    """Apply the case-study augmentations. Horizontal flip stays off.

    Left/right hand classes are mirror images of each other. A flip would
    assign a texting-left frame the texting-right label, so it is not used.
    """
    rng = rng or np.random.default_rng()
    image = Image.fromarray((np.clip(array, 0, 1) * 255).astype(np.uint8))

    angle = float(rng.uniform(-AUGMENTATION["rotation_degrees"], AUGMENTATION["rotation_degrees"]))
    image = image.rotate(angle, resample=Image.BILINEAR, fillcolor=(0, 0, 0))

    width, height = image.size
    max_dx = int(width * AUGMENTATION["width_shift"])
    max_dy = int(height * AUGMENTATION["height_shift"])
    dx = int(rng.integers(-max_dx, max_dx + 1)) if max_dx else 0
    dy = int(rng.integers(-max_dy, max_dy + 1)) if max_dy else 0
    image = image.transform(
        image.size,
        Image.AFFINE,
        (1, 0, dx, 0, 1, dy),
        resample=Image.BILINEAR,
        fillcolor=(0, 0, 0),
    )

    zoom = float(rng.uniform(1 - AUGMENTATION["zoom_range"], 1 + AUGMENTATION["zoom_range"]))
    crop_w = max(1, int(width / zoom))
    crop_h = max(1, int(height / zoom))
    left = max(0, (width - crop_w) // 2)
    top = max(0, (height - crop_h) // 2)
    image = image.crop((left, top, left + crop_w, top + crop_h)).resize(
        (width, height), Image.BILINEAR
    )

    low, high = AUGMENTATION["brightness_range"]
    image = ImageEnhance.Brightness(image).enhance(float(rng.uniform(low, high)))
    return np.asarray(image, dtype=np.float32) / 255.0


def batch_iterator(
    records: list[dict],
    train_root: Path,
    batch_size: int,
    augment: bool,
    seed: int,
    size: tuple[int, int] = IMAGE_SIZE,
):
    """Yield (images, one-hot labels) batches. Training batches are shuffled."""
    rng = np.random.default_rng(seed)
    order = np.arange(len(records))
    class_to_index = {class_id: i for i, class_id in enumerate(CLASS_IDS)}
    while True:
        rng.shuffle(order)
        for start in range(0, len(order), batch_size):
            chunk = order[start : start + batch_size]
            images = []
            labels = np.zeros((len(chunk), len(CLASS_IDS)), dtype=np.float32)
            for row_i, index in enumerate(chunk):
                record = records[int(index)]
                image = load_image(resolve_image_path(train_root, record), size)
                if augment:
                    image = augment_image(image, rng)
                images.append(image)
                labels[row_i, class_to_index[record["classname"]]] = 1.0
            yield np.stack(images), labels
