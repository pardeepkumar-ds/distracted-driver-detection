"""Transfer-learning models for the improvement step of the case study.

MobileNetV2 is the default because it is small enough to fine-tune on a
single GPU and was designed for 224x224 inputs. VGG16 and ResNet50 are
available behind the same interface. The ImageNet trunk is frozen for the
first phase so the new 10-class head can learn without destroying pretrained
filters; a second phase unfreezes the top of the trunk at a lower learning rate.
"""

from config import IMAGE_SIZE


def build_transfer_model(backbone: str = "mobilenet_v2", learning_rate: float = 1e-4):
    from tensorflow import keras
    from tensorflow.keras import layers
    from tensorflow.keras.applications import MobileNetV2, ResNet50, VGG16

    builders = {
        "mobilenet_v2": MobileNetV2,
        "vgg16": VGG16,
        "resnet50": ResNet50,
    }
    if backbone not in builders:
        raise ValueError(f"backbone must be one of {sorted(builders)}")

    base = builders[backbone](
        include_top=False,
        weights="imagenet",
        input_shape=(IMAGE_SIZE[0], IMAGE_SIZE[1], 3),
        pooling="avg",
    )
    base.trainable = False

    inputs = keras.Input(shape=(IMAGE_SIZE[0], IMAGE_SIZE[1], 3))
    # MobileNet/ResNet expect caffe-style or tf-style preprocessing. The
    # application preprocess_input call is applied in train.py, not here,
    # so this graph stays a plain classifier head on normalized features.
    x = base(inputs, training=False)
    x = layers.Dense(128, activation="relu", name="transfer_head")(x)
    x = layers.Dropout(0.40, name="transfer_dropout")(x)
    outputs = layers.Dense(10, activation="softmax", name="class_probabilities")(x)
    model = keras.Model(inputs, outputs, name=f"distracted_{backbone}")
    model.compile(
        optimizer=keras.optimizers.Adam(learning_rate=learning_rate),
        loss="categorical_crossentropy",
        metrics=["accuracy"],
    )
    return model, base


def unfreeze_for_finetune(model, base, learning_rate: float = 1e-5, unfreeze_layers: int = 20):
    """Second-phase fine-tune: open the last blocks of the trunk."""
    from tensorflow import keras

    base.trainable = True
    for layer in base.layers[:-unfreeze_layers]:
        layer.trainable = False
    model.compile(
        optimizer=keras.optimizers.Adam(learning_rate=learning_rate),
        loss="categorical_crossentropy",
        metrics=["accuracy"],
    )
    return model
