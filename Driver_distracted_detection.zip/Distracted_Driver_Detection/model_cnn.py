"""Custom CNN specified by the case study, built in Keras.

Input is a 224x224 RGB dashboard frame. Four conv-pool blocks extract
features, dropout limits co-adaptation, and a 10-way softmax matches the
State Farm classes. Categorical cross-entropy, Adam, and accuracy are the
compile settings required by the brief. Macro F1 is computed at evaluation
time so a weak minority class cannot hide behind overall accuracy.
"""

from config import IMAGE_SIZE, LEARNING_RATE


def build_cnn(learning_rate: float = LEARNING_RATE):
    from tensorflow import keras
    from tensorflow.keras import layers

    inputs = keras.Input(shape=(IMAGE_SIZE[0], IMAGE_SIZE[1], 3), name="dashboard_frame")
    x = layers.Conv2D(32, 3, padding="same", activation="relu", name="conv1")(inputs)
    x = layers.MaxPooling2D(2, name="pool1")(x)
    x = layers.Conv2D(64, 3, padding="same", activation="relu", name="conv2")(x)
    x = layers.MaxPooling2D(2, name="pool2")(x)
    x = layers.Conv2D(128, 3, padding="same", activation="relu", name="conv3")(x)
    x = layers.MaxPooling2D(2, name="pool3")(x)
    x = layers.Conv2D(128, 3, padding="same", activation="relu", name="conv4")(x)
    x = layers.MaxPooling2D(2, name="pool4")(x)
    x = layers.Dropout(0.30, name="dropout_spatial")(x)
    x = layers.Flatten(name="flatten")(x)
    x = layers.Dense(256, activation="relu", name="dense_features")(x)
    x = layers.Dropout(0.50, name="dropout_dense")(x)
    outputs = layers.Dense(10, activation="softmax", name="class_probabilities")(x)

    model = keras.Model(inputs, outputs, name="distracted_driver_cnn")
    model.compile(
        optimizer=keras.optimizers.Adam(learning_rate=learning_rate),
        loss="categorical_crossentropy",
        metrics=["accuracy"],
    )
    return model


def training_callbacks(checkpoint_path: str):
    """Early stopping and learning-rate scheduling, as required in step 5."""
    from tensorflow import keras

    return [
        keras.callbacks.EarlyStopping(
            monitor="val_loss",
            patience=5,
            restore_best_weights=True,
        ),
        keras.callbacks.ReduceLROnPlateau(
            monitor="val_loss",
            factor=0.5,
            patience=2,
            min_lr=1e-6,
        ),
        keras.callbacks.ModelCheckpoint(
            checkpoint_path,
            monitor="val_loss",
            save_best_only=True,
        ),
    ]


def parameter_table() -> list[dict]:
    """Hand-checked parameter counts for the architecture above.

    Conv params = kernel_h * kernel_w * in_channels * filters + filters.
    Dense params = in_features * units + units.
    """
    return [
        {"layer": "conv1 3x3, 32", "output": "224x224x32", "params": 3 * 3 * 3 * 32 + 32},
        {"layer": "pool1 2x2", "output": "112x112x32", "params": 0},
        {"layer": "conv2 3x3, 64", "output": "112x112x64", "params": 3 * 3 * 32 * 64 + 64},
        {"layer": "pool2 2x2", "output": "56x56x64", "params": 0},
        {"layer": "conv3 3x3, 128", "output": "56x56x128", "params": 3 * 3 * 64 * 128 + 128},
        {"layer": "pool3 2x2", "output": "28x28x128", "params": 0},
        {"layer": "conv4 3x3, 128", "output": "28x28x128", "params": 3 * 3 * 128 * 128 + 128},
        {"layer": "pool4 2x2", "output": "14x14x128", "params": 0},
        {"layer": "dropout 0.30", "output": "14x14x128", "params": 0},
        {"layer": "flatten", "output": "25088", "params": 0},
        {"layer": "dense 256", "output": "256", "params": 25088 * 256 + 256},
        {"layer": "dropout 0.50", "output": "256", "params": 0},
        {"layer": "softmax 10", "output": "10", "params": 256 * 10 + 10},
    ]
