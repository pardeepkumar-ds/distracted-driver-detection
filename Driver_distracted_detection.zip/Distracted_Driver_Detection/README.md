# Distracted Driver Detection Using Deep Learning

Case study project for classifying dashboard-camera frames into the 10 State Farm distracted-driving activities.

## What is included

- `config.py` — official Kaggle class ids, published training counts, augmentation settings.
- `data_preprocessing.py` — csv loading, driver-grouped train/validation/test split, 224x224 resize, augmentation.
- `model_cnn.py` — the case-study CNN (conv, pool, dropout, dense, 10-way softmax), Adam, categorical cross-entropy.
- `model_transfer.py` — MobileNetV2, VGG16, or ResNet50 transfer-learning improvement.
- `train.py` — training with early stopping and learning-rate scheduling.
- `evaluate.py` — accuracy, per-class precision, recall, F1, confusion matrix.
- `run_verification.py` — the experiment that was actually executed on this machine.
- `results/` — measured metrics and figures from that run.

## Class ids

The assignment brief lists texting-left before talking-on-the-phone-right. The dataset files do not. This project follows `driver_imgs_list.csv`:

| Id | Activity |
| --- | --- |
| c0 | Safe driving |
| c1 | Texting - right |
| c2 | Talking on the phone - right |
| c3 | Texting - left |
| c4 | Talking on the phone - left |
| c5 | Operating the radio |
| c6 | Drinking |
| c7 | Reaching behind |
| c8 | Hair and makeup |
| c9 | Talking to passenger |

Horizontal flip is off. A flip swaps the left-hand and right-hand classes.

## Run the full model

1. Accept the rules and download the archive from the Kaggle competition *State Farm Distracted Driver Detection* (4.31 GB).
2. Unzip so the tree is `data/driver_imgs_list.csv` and `data/imgs/train/c0/...`.
3. Install TensorFlow, then:

```bash
pip install -r requirements.txt tensorflow
python train.py --data-dir data --model cnn
python train.py --data-dir data --model mobilenet_v2
```

## Run the verification experiment

```bash
pip install -r requirements.txt
python run_verification.py
```

That run uses schematic 28x28 class cues, not State Farm photographs. The report states this limit in the evaluation section. Figures land in `results/`.
