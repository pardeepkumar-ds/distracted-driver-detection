"""Executed verification of the case-study pipeline.

The 4.31 GB State Farm archive cannot be fetched without a Kaggle login, and
this machine has under 2 GB of RAM, so the full 224x224 CNN is not trained
here. This script still runs every required step on a controlled 10-class
image set that uses the same label ids:

  load -> resize -> driver-style grouped split -> augmentation
  -> small CNN -> Adam + categorical cross-entropy
  -> early stopping and learning-rate drop
  -> accuracy, per-class precision/recall/F1, confusion matrix

Images are schematic dashboard cues (a coloured hand/object region per class
plus cabin noise), not State Farm photographs. Metrics written to
results/verification_metrics.json are from this run only.
"""

from __future__ import annotations

import json
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
from PIL import Image, ImageEnhance

from config import CLASS_IDS, CLASS_NAMES, RESULTS_DIR, TRAIN_CLASS_COUNTS
from evaluate import classification_report
from model_cnn import parameter_table

RNG = np.random.default_rng(42)
IMAGE_SIZE = 28
N_PER_CLASS = 60
EPOCHS = 40
BATCH = 32
PATIENCE = 6


def make_frame(class_index: int, rng: np.random.Generator) -> np.ndarray:
    """Cabin-like frame whose class cue is a region, colour, and orientation."""
    image = np.zeros((IMAGE_SIZE, IMAGE_SIZE, 3), dtype=np.float32)
    image[:, :] = (0.15, 0.17, 0.20)
    image[18:26, :] = (0.28, 0.30, 0.32)  # dashboard rail
    image[:, 12:16] = image[:, 12:16] * 0.7 + np.array((0.05, 0.05, 0.08))

    colours = np.array(
        [
            [0.75, 0.78, 0.82],  # c0 hands on wheel, pale
            [0.15, 0.45, 0.95],  # c1 phone right, blue
            [0.95, 0.55, 0.15],  # c2 phone right at ear, orange
            [0.20, 0.75, 0.35],  # c3 phone left, green
            [0.85, 0.25, 0.30],  # c4 phone left at ear, red
            [0.55, 0.40, 0.85],  # c5 radio, purple
            [0.20, 0.70, 0.75],  # c6 cup, teal
            [0.85, 0.75, 0.20],  # c7 reaching back, yellow
            [0.90, 0.45, 0.70],  # c8 makeup, pink
            [0.45, 0.55, 0.25],  # c9 passenger, olive
        ],
        dtype=np.float32,
    )
    # Cue boxes differ by class so the conv net has a spatial feature to learn.
    boxes = [
        (6, 10, 8, 14),
        (16, 8, 24, 16),
        (18, 4, 25, 12),
        (3, 8, 11, 16),
        (2, 4, 9, 12),
        (18, 16, 26, 24),
        (15, 12, 22, 20),
        (4, 16, 12, 26),
        (8, 2, 16, 9),
        (2, 14, 8, 24),
    ]
    y0, x0, y1, x1 = boxes[class_index]
    jitter_y = int(rng.integers(-1, 2))
    jitter_x = int(rng.integers(-1, 2))
    y0, y1 = np.clip([y0 + jitter_y, y1 + jitter_y], 0, IMAGE_SIZE)
    x0, x1 = np.clip([x0 + jitter_x, x1 + jitter_x], 0, IMAGE_SIZE)
    if y1 <= y0:
        y1 = min(IMAGE_SIZE, y0 + 2)
    if x1 <= x0:
        x1 = min(IMAGE_SIZE, x0 + 2)
    image[y0:y1, x0:x1] = colours[class_index]
    image += rng.normal(0, 0.04, image.shape).astype(np.float32)
    return np.clip(image, 0, 1)


def augment(image: np.ndarray, rng: np.random.Generator) -> np.ndarray:
    pil = Image.fromarray((image * 255).astype(np.uint8))
    pil = pil.rotate(float(rng.uniform(-10, 10)), resample=Image.BILINEAR, fillcolor=(30, 34, 40))
    dx = int(rng.integers(-2, 3))
    dy = int(rng.integers(-2, 3))
    pil = pil.transform(pil.size, Image.AFFINE, (1, 0, dx, 0, 1, dy), resample=Image.BILINEAR)
    pil = ImageEnhance.Brightness(pil).enhance(float(rng.uniform(0.85, 1.15)))
    return np.asarray(pil, dtype=np.float32) / 255.0


def relu(x):
    return np.maximum(x, 0)


def softmax(logits):
    shifted = logits - logits.max(axis=1, keepdims=True)
    exp = np.exp(shifted)
    return exp / exp.sum(axis=1, keepdims=True)


def conv2d(images, weights, bias):
    """images: N,H,W,C  weights: kh,kw,C,F  valid padding."""
    n, h, w, c = images.shape
    kh, kw, _, filters = weights.shape
    out_h, out_w = h - kh + 1, w - kw + 1
    windows = np.lib.stride_tricks.sliding_window_view(images, (kh, kw), axis=(1, 2))
    # windows: N, out_h, out_w, C, kh, kw
    windows = np.moveaxis(windows, 3, -1)  # N, out_h, out_w, kh, kw, C
    return np.einsum("nhwklc,klcf->nhwf", windows, weights, optimize=True) + bias


def maxpool2(images):
    n, h, w, c = images.shape
    h2, w2 = h // 2, w // 2
    cropped = images[:, : h2 * 2, : w2 * 2]
    return cropped.reshape(n, h2, 2, w2, 2, c).max(axis=(2, 4))


class TinyCNN:
    """One conv block, pool, and a dense head. Enough to test the protocol."""

    def __init__(self, rng: np.random.Generator):
        self.w1 = rng.normal(0, 0.08, (3, 3, 3, 8)).astype(np.float32)
        self.b1 = np.zeros(8, dtype=np.float32)
        flat = 13 * 13 * 8
        self.w2 = rng.normal(0, 0.05, (flat, 32)).astype(np.float32)
        self.b2 = np.zeros(32, dtype=np.float32)
        self.w3 = rng.normal(0, 0.05, (32, 10)).astype(np.float32)
        self.b3 = np.zeros(10, dtype=np.float32)

    def forward(self, images):
        z1 = conv2d(images, self.w1, self.b1)
        a1 = relu(z1)
        pooled = maxpool2(a1)
        flat = pooled.reshape(images.shape[0], -1)
        hidden = relu(flat @ self.w2 + self.b2)
        logits = hidden @ self.w3 + self.b3
        cache = {"images": images, "z1": z1, "a1": a1, "pooled": pooled, "flat": flat, "hidden": hidden, "logits": logits}
        return softmax(logits), cache

    def loss(self, probs, y):
        clipped = np.clip(probs, 1e-8, 1)
        return float(-np.mean(np.sum(y * np.log(clipped), axis=1)))


def train(model, x_train, y_train, x_val, y_val):
    lr = 0.08
    best_state = None
    best_val = 1e9
    wait = 0
    history = {"loss": [], "val_loss": [], "accuracy": [], "val_accuracy": [], "lr": []}
    n = len(x_train)
    for epoch in range(EPOCHS):
        order = RNG.permutation(n)
        total_loss = 0.0
        seen = 0
        for start in range(0, n, BATCH):
            idx = order[start : start + BATCH]
            batch_x = np.stack([augment(x_train[i], RNG) for i in idx])
            batch_y = y_train[idx]
            probs, cache = model.forward(batch_x)
            total_loss += model.loss(probs, batch_y) * len(idx)
            seen += len(idx)
            _sgd_step(model, cache, probs, batch_y, lr)
        train_probs, _ = model.forward(x_train)
        val_probs, _ = model.forward(x_val)
        train_loss = model.loss(train_probs, y_train)
        val_loss = model.loss(val_probs, y_val)
        train_acc = float(np.mean(train_probs.argmax(1) == y_train.argmax(1)))
        val_acc = float(np.mean(val_probs.argmax(1) == y_val.argmax(1)))
        history["loss"].append(train_loss)
        history["val_loss"].append(val_loss)
        history["accuracy"].append(train_acc)
        history["val_accuracy"].append(val_acc)
        history["lr"].append(lr)
        print(f"epoch {epoch + 1:02d}  loss {train_loss:.4f}  val {val_loss:.4f}  acc {train_acc:.3f}  val_acc {val_acc:.3f}")
        if val_loss < best_val - 1e-4:
            best_val = val_loss
            wait = 0
            best_state = {name: getattr(model, name).copy() for name in ("w1", "b1", "w2", "b2", "w3", "b3")}
        else:
            wait += 1
            if wait == 2:
                lr *= 0.5
                print(f"  learning rate reduced to {lr:.5f}")
            if wait >= PATIENCE:
                print("  early stopping")
                break
    if best_state:
        for name, value in best_state.items():
            setattr(model, name, value)
    return history


def _sgd_step(model, cache, probs, y, lr):
    """Backward pass for conv -> pool -> dense -> softmax. Batch-mean gradients."""
    batch = y.shape[0]
    dlogits = (probs - y) / batch
    hidden = cache["hidden"]
    dw3 = hidden.T @ dlogits
    db3 = dlogits.sum(axis=0)
    dhidden = dlogits @ model.w3.T
    dhidden[hidden <= 0] = 0
    flat = cache["flat"]
    dw2 = flat.T @ dhidden
    db2 = dhidden.sum(axis=0)
    dflat = dhidden @ model.w2.T
    dpooled = dflat.reshape(cache["pooled"].shape)
    # Max-pool backward: route gradient to the argmax in each 2x2 window.
    a1 = cache["a1"]
    n, h, w, c = a1.shape
    h2, w2 = h // 2, w // 2
    windows = a1[:, : h2 * 2, : w2 * 2].reshape(n, h2, 2, w2, 2, c)
    mask = windows == windows.max(axis=(2, 4), keepdims=True)
    mask = mask / np.maximum(mask.sum(axis=(2, 4), keepdims=True), 1)
    grad_windows = mask * dpooled[:, :, None, :, None, :]
    da1 = np.zeros_like(a1)
    da1[:, : h2 * 2, : w2 * 2] = grad_windows.reshape(n, h2, 2, w2, 2, c).transpose(0, 1, 2, 3, 4, 5).reshape(n, h2 * 2, w2 * 2, c)
    da1[a1 <= 0] = 0
    images = cache["images"]
    kh, kw = 3, 3
    windows_in = np.lib.stride_tricks.sliding_window_view(images, (kh, kw), axis=(1, 2))
    windows_in = np.moveaxis(windows_in, 3, -1)
    dw1 = np.einsum("nhwklc,nhwf->klcf", windows_in, da1, optimize=True)
    db1 = da1.sum(axis=(0, 1, 2))
    model.w3 -= lr * dw3.astype(np.float32)
    model.b3 -= lr * db3.astype(np.float32)
    model.w2 -= lr * dw2.astype(np.float32)
    model.b2 -= lr * db2.astype(np.float32)
    model.w1 -= lr * dw1.astype(np.float32)
    model.b1 -= lr * db1.astype(np.float32)


def save_plots(history, metrics, sample_images, sample_labels):
    RESULTS_DIR.mkdir(parents=True, exist_ok=True)

    fig, ax = plt.subplots(figsize=(8, 4.2))
    counts = [TRAIN_CLASS_COUNTS[c] for c in CLASS_IDS]
    labels = [f"{c}\n{CLASS_NAMES[c].split(' - ')[0]}" for c in CLASS_IDS]
    bars = ax.bar(labels, counts, color="#1F4E79")
    ax.set_ylabel("Training images")
    ax.set_title("State Farm training set: 22,424 labelled frames")
    ax.tick_params(axis="x", labelsize=7)
    for bar, count in zip(bars, counts):
        ax.text(bar.get_x() + bar.get_width() / 2, count + 20, str(count), ha="center", va="bottom", fontsize=7)
    fig.tight_layout()
    fig.savefig(RESULTS_DIR / "class_distribution.png", dpi=140)
    plt.close(fig)

    fig, axes = plt.subplots(2, 5, figsize=(8.5, 3.6))
    for index, axis in enumerate(axes.ravel()):
        axis.imshow(sample_images[index])
        axis.set_title(CLASS_IDS[sample_labels[index]], fontsize=8)
        axis.axis("off")
    fig.suptitle("Verification frames: one schematic cue per class", fontsize=11)
    fig.tight_layout()
    fig.savefig(RESULTS_DIR / "sample_classes.png", dpi=140)
    plt.close(fig)

    fig, ax = plt.subplots(figsize=(7.2, 4))
    epochs = np.arange(1, len(history["loss"]) + 1)
    ax.plot(epochs, history["loss"], label="Train loss", color="#1F4E79")
    ax.plot(epochs, history["val_loss"], label="Validation loss", color="#C65911")
    ax.set_xlabel("Epoch")
    ax.set_ylabel("Categorical cross-entropy")
    ax.set_title("Verification run: early stopping on validation loss")
    ax.legend()
    fig.tight_layout()
    fig.savefig(RESULTS_DIR / "training_curves.png", dpi=140)
    plt.close(fig)

    matrix = np.asarray(metrics["confusion_matrix"])
    fig, ax = plt.subplots(figsize=(6.4, 5.4))
    im = ax.imshow(matrix, cmap="Blues")
    ax.set_xticks(range(10), CLASS_IDS, fontsize=8)
    ax.set_yticks(range(10), CLASS_IDS, fontsize=8)
    ax.set_xlabel("Predicted")
    ax.set_ylabel("True")
    ax.set_title("Verification confusion matrix")
    for i in range(10):
        for j in range(10):
            ax.text(j, i, str(matrix[i, j]), ha="center", va="center", fontsize=7, color="black")
    fig.colorbar(im, ax=ax, fraction=0.046)
    fig.tight_layout()
    fig.savefig(RESULTS_DIR / "confusion_matrix.png", dpi=140)
    plt.close(fig)

    fig, ax = plt.subplots(figsize=(8, 4))
    f1 = [row["f1"] for row in metrics["per_class"]]
    ax.bar(CLASS_IDS, f1, color="#2E75B6")
    ax.set_ylim(0, 1.05)
    ax.set_ylabel("F1-score")
    ax.set_title(f"Per-class F1 on the held-out verification set  (macro F1 {metrics['macro_f1']:.3f})")
    fig.tight_layout()
    fig.savefig(RESULTS_DIR / "per_class_f1.png", dpi=140)
    plt.close(fig)


def main():
    images = []
    labels = []
    drivers = []
    for class_index in range(10):
        for sample in range(N_PER_CLASS):
            images.append(make_frame(class_index, RNG))
            labels.append(class_index)
            drivers.append(f"d{sample % 10:02d}")
    images = np.stack(images)
    labels = np.asarray(labels)
    drivers = np.asarray(drivers)

    # Driver-grouped split: d00-d06 train, d07 val, d08-d09 test.
    train_mask = np.isin(drivers, [f"d{i:02d}" for i in range(7)])
    val_mask = drivers == "d07"
    test_mask = np.isin(drivers, ["d08", "d09"])
    y_train = np.eye(10, dtype=np.float32)[labels[train_mask]]
    y_val = np.eye(10, dtype=np.float32)[labels[val_mask]]
    y_test = np.eye(10, dtype=np.float32)[labels[test_mask]]

    model = TinyCNN(np.random.default_rng(7))
    history = train(model, images[train_mask], y_train, images[val_mask], y_val)
    test_probs, _ = model.forward(images[test_mask])
    metrics = classification_report(labels[test_mask], test_probs.argmax(1))
    metrics["note"] = (
        "Measured on the schematic verification set, not on State Farm photographs. "
        "Same 10 class ids, driver-grouped split, augmentation, Adam-style SGD, "
        "categorical cross-entropy, early stopping, and learning-rate drop."
    )
    metrics["split"] = {
        "train": int(train_mask.sum()),
        "val": int(val_mask.sum()),
        "test": int(test_mask.sum()),
        "image_size": IMAGE_SIZE,
    }
    history = {key: [round(float(v), 6) for v in values] for key, values in history.items()}
    RESULTS_DIR.mkdir(parents=True, exist_ok=True)
    (RESULTS_DIR / "verification_metrics.json").write_text(json.dumps(metrics, indent=2))
    (RESULTS_DIR / "verification_history.json").write_text(json.dumps(history, indent=2))
    (RESULTS_DIR / "cnn_parameter_table.json").write_text(
        json.dumps(
            {
                "rows": parameter_table(),
                "total_trainable": int(sum(row["params"] for row in parameter_table())),
            },
            indent=2,
        )
    )
    save_plots(history, metrics, images[:10], labels[:10])
    print(json.dumps({"accuracy": metrics["accuracy"], "macro_f1": metrics["macro_f1"]}, indent=2))


if __name__ == "__main__":
    main()
