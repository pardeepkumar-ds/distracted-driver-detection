"""Train the case-study CNN, or a transfer model, on the State Farm images.

Usage (from this directory, after the Kaggle archive is unzipped):

    python train.py --data-dir data --model cnn
    python train.py --data-dir data --model mobilenet_v2

The 4.31 GB imgs.zip is not bundled. Download it from the Kaggle competition
"State Farm Distracted Driver Detection" after accepting the rules, unzip it
so that data/imgs/train/c0 exists, and place driver_imgs_list.csv in data/.
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np

from config import (
    BATCH_SIZE,
    EPOCHS,
    LEARNING_RATE,
    RANDOM_SEED,
    RESULTS_DIR,
    TEST_FRACTION,
    VAL_FRACTION,
)
from data_preprocessing import batch_iterator, driver_grouped_split, load_driver_index
from evaluate import evaluate_split


def parse_args():
    parser = argparse.ArgumentParser(description="Train distracted-driver classifier")
    parser.add_argument("--data-dir", type=Path, default=Path("data"))
    parser.add_argument("--model", choices=["cnn", "mobilenet_v2", "vgg16", "resnet50"], default="cnn")
    parser.add_argument("--epochs", type=int, default=EPOCHS)
    parser.add_argument("--batch-size", type=int, default=BATCH_SIZE)
    return parser.parse_args()


def main():
    args = parse_args()
    csv_path = args.data_dir / "driver_imgs_list.csv"
    train_root = args.data_dir / "imgs" / "train"
    if not csv_path.exists() or not train_root.exists():
        raise SystemExit(
            "Dataset not found. Expected data/driver_imgs_list.csv and "
            "data/imgs/train/c0. Download the State Farm archive from Kaggle "
            "and unzip it into data/."
        )

    records = load_driver_index(csv_path)
    splits = driver_grouped_split(records, VAL_FRACTION, TEST_FRACTION, RANDOM_SEED)
    RESULTS_DIR.mkdir(parents=True, exist_ok=True)
    (RESULTS_DIR / "split.json").write_text(
        json.dumps(
            {
                "train_drivers": splits["train_drivers"],
                "val_drivers": splits["val_drivers"],
                "test_drivers": splits["test_drivers"],
                "train_images": len(splits["train"]),
                "val_images": len(splits["val"]),
                "test_images": len(splits["test"]),
            },
            indent=2,
        )
    )

    if args.model == "cnn":
        from model_cnn import build_cnn, training_callbacks

        model = build_cnn(LEARNING_RATE)
        callbacks = training_callbacks(str(RESULTS_DIR / "cnn_best.keras"))
    else:
        from model_transfer import build_transfer_model
        from model_cnn import training_callbacks

        model, _base = build_transfer_model(args.model, learning_rate=1e-4)
        callbacks = training_callbacks(str(RESULTS_DIR / f"{args.model}_best.keras"))

    train_steps = int(np.ceil(len(splits["train"]) / args.batch_size))
    val_steps = int(np.ceil(len(splits["val"]) / args.batch_size))
    history = model.fit(
        batch_iterator(splits["train"], train_root, args.batch_size, True, RANDOM_SEED),
        validation_data=batch_iterator(
            splits["val"], train_root, args.batch_size, False, RANDOM_SEED + 1
        ),
        steps_per_epoch=train_steps,
        validation_steps=val_steps,
        epochs=args.epochs,
        callbacks=callbacks,
    )
    (RESULTS_DIR / "history.json").write_text(json.dumps(history.history, indent=2))
    metrics = evaluate_split(model, splits["test"], train_root, args.batch_size)
    (RESULTS_DIR / "test_metrics.json").write_text(json.dumps(metrics, indent=2))
    print(json.dumps(metrics, indent=2))


if __name__ == "__main__":
    main()
