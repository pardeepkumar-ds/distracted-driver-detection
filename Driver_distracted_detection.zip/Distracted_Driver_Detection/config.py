"""Shared configuration for the Distracted Driver Detection case study.

Class ids follow the State Farm / Kaggle label files, not the numbered list in
the assignment brief. The brief swaps the second and third activity relative
to the files: Kaggle c2 is talking on the phone (right), c3 is texting (left).
Training code must follow the file labels or every metric will be wrong.
"""

from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parent
RESULTS_DIR = PROJECT_ROOT / "results"

# Official State Farm class ids (driver_imgs_list.csv / sample_submission.csv).
CLASS_IDS = [f"c{i}" for i in range(10)]
CLASS_NAMES = {
    "c0": "Safe driving",
    "c1": "Texting - right",
    "c2": "Talking on the phone - right",
    "c3": "Texting - left",
    "c4": "Talking on the phone - left",
    "c5": "Operating the radio",
    "c6": "Drinking",
    "c7": "Reaching behind",
    "c8": "Hair and makeup",
    "c9": "Talking to passenger",
}

# Row counts of the public driver_imgs_list.csv (22,424 labelled training images,
# 26 drivers). Test images are a separate, driver-disjoint, unlabelled set of
# 79,726 frames. Counts are the standard competition totals.
TRAIN_CLASS_COUNTS = {
    "c0": 2489,
    "c1": 2267,
    "c2": 2317,
    "c3": 2346,
    "c4": 2326,
    "c5": 2312,
    "c6": 2325,
    "c7": 2002,
    "c8": 1911,
    "c9": 2129,
}

IMAGE_SIZE = (224, 224)
BATCH_SIZE = 32
EPOCHS = 25
LEARNING_RATE = 1e-3
EARLY_STOP_PATIENCE = 5
LR_PLATEAU_PATIENCE = 2
VAL_FRACTION = 0.15
TEST_FRACTION = 0.15
RANDOM_SEED = 42

# Horizontal flip is intentionally off. Flipping a left-hand texting frame
# turns it into a right-hand texting frame and corrupts the label.
AUGMENTATION = {
    "rotation_degrees": 12,
    "width_shift": 0.08,
    "height_shift": 0.08,
    "zoom_range": 0.10,
    "brightness_range": (0.85, 1.15),
    "horizontal_flip": False,
}
